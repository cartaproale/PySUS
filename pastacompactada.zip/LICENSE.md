CC0 1.0 Universal (CC0 1.0) Public Domain Dedication

To the extent possible under law, Alexandre Kraemer has waived all copyright 
and related or neighboring rights to this work.

You can copy, modify, distribute and perform the work, even for commercial purposes, all without asking permission.
